// Code generated from Pkl module `formation`. DO NOT EDIT.
package pkltest

import "github.com/apple/pkl-go/pkl"

func init() {
	pkl.RegisterMapping("formation", Formation{})
}
