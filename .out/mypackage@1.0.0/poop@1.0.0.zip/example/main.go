package main

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"

	"bitbucket.org/zetaactions/pkltest"
	"github.com/apple/pkl-go/pkl"
)

func main() {
	// formation, err := pkltest.LoadFromPath(context.Background(), "environment/dev-edu/main.pkl")
	// formation, err := LoadFromHTTP(context.Background(), "http://localhost:8080/formation/dev-edu")
	// if err != nil {
	// 	panic(err)
	// }
	var formation *pkltest.Formation
	res, err := http.Get("http://localhost:8080/formation/dev-edu")
	if err != nil {
		panic(err)
	}
	defer res.Body.Close()
	err = json.NewDecoder(res.Body).Decode(&formation)
	if err != nil {
		panic(err)

	}
	encoded, _ := json.Marshal(formation)

	fmt.Println(string(encoded))

}

func LoadFromHTTP(ctx context.Context, http string) (ret *pkltest.Formation, err error) {
	evaluator, err := pkl.NewEvaluator(ctx, pkl.PreconfiguredOptions)
	if err != nil {
		return nil, err
	}
	defer func() {
		cerr := evaluator.Close()
		if err == nil {
			err = cerr
		}
	}()
	ret, err = pkltest.Load(ctx, evaluator, pkl.UriSource(http))
	return ret, err
}
