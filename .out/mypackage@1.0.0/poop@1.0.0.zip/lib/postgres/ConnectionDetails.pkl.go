// Code generated from Pkl module `Postgres`. DO NOT EDIT.
package postgres

type ConnectionDetails interface {
	GetUsername() string

	GetPassword() string

	GetHost() string

	GetPort() int

	GetDbName() string
}
