// Code generated from Pkl module `Postgres`. DO NOT EDIT.
package postgres

import "github.com/apple/pkl-go/pkl"

func init() {
	pkl.RegisterMapping("Postgres", Postgres{})
}
