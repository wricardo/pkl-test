// Code generated from Pkl module `Redis`. DO NOT EDIT.
package redis

import "github.com/apple/pkl-go/pkl"

func init() {
	pkl.RegisterMapping("Redis#ConnectionDetails", ConnectionDetailsImpl{})
	pkl.RegisterMapping("Redis", Redis{})
}
