// Code generated from Pkl module `Redis`. DO NOT EDIT.
package redis

type ConnectionDetails interface {
	IConnectionDetails
}

var _ ConnectionDetails = (*ConnectionDetailsImpl)(nil)

type ConnectionDetailsImpl struct {
	Host string `pkl:"host"`
}

func (rcv *ConnectionDetailsImpl) GetHost() string {
	return rcv.Host
}
