// Code generated from Pkl module `Redis`. DO NOT EDIT.
package redis

type IConnectionDetails interface {
	GetHost() string
}
