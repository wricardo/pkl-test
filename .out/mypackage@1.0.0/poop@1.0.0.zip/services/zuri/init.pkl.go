// Code generated from Pkl module `Zuri`. DO NOT EDIT.
package zuri

import "github.com/apple/pkl-go/pkl"

func init() {
	pkl.RegisterMapping("Zuri", ZuriImpl{})
	pkl.RegisterMapping("Zuri#ZuriDb", ZuriDbImpl{})
}
