// Code generated from Pkl module `Kosmos`. DO NOT EDIT.
package kosmos

import "github.com/apple/pkl-go/pkl"

func init() {
	pkl.RegisterMapping("Kosmos", KosmosImpl{})
	pkl.RegisterMapping("Kosmos#Postgres", PostgresImpl{})
}
