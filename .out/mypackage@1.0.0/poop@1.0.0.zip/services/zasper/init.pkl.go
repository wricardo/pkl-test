// Code generated from Pkl module `Zasper`. DO NOT EDIT.
package zasper

import "github.com/apple/pkl-go/pkl"

func init() {
	pkl.RegisterMapping("Zasper", ZasperImpl{})
}
