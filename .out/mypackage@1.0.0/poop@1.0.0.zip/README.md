# pkl-test

Service
- zuri
- zasper
- kosmos
- kosmos-ui

Personality
- Local
- Edu
- Apptness

Environment
- local
- development-edu
- development-apptness
- production-edu
- production-apptess
